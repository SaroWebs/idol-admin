import MasterLayout from '@/Layouts/MasterLayout'
import React from 'react'

const Account = (props) => {
  return (
    <MasterLayout {...props}>Account</MasterLayout>
  )
}

export default Account