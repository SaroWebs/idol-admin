import React from 'react'

const TaxList = () => {
  return (
    <div>TaxList</div>
  )
}

export default TaxList