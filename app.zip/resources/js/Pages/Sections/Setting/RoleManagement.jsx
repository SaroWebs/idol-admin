import React from 'react'

const RoleManagement = () => {
  return (
    <div>RoleManagement</div>
  )
}

export default RoleManagement