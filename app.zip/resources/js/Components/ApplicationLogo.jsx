export default function ApplicationLogo(props) {
    return (
        <img src="/assets/images/logo.png" alt="logo" {...props} />
    );
}
