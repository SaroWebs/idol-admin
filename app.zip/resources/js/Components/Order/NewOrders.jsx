import React from 'react'

const NewOrders = () => {
  return (
    <div>NewOrders</div>
  )
}

export default NewOrders