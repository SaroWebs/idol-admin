import React from 'react'

const CompleteOrders = () => {
  return (
    <div>CompleteOrders</div>
  )
}

export default CompleteOrders