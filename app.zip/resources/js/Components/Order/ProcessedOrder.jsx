import React from 'react'

const ProcessedOrder = () => {
  return (
    <div>ProcessedOrder</div>
  )
}

export default ProcessedOrder