<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrderPaymentController extends Controller
{
    //
}
