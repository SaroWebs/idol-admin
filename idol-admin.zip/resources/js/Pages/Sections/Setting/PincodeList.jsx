import React from 'react'

const PincodeList = () => {
  return (
    <div>PincodeList</div>
  )
}

export default PincodeList