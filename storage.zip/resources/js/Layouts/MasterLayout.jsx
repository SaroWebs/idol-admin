import React from 'react'

const MasterLayout = (props) => {
  return (
    <div>{props.children}</div>
  )
}

export default MasterLayout